package ru.geekbrains.lesson1;

public class MainOne {
    public static void main(String[] args) {
       System.out.println("Первое домашнее задание");
            }

            private static double maxOne( int a, int b, int c, int d) {
            a = 7;
            b = 8;
            c = 6;
            d = 2;
            double v = a * (b + ((double) c / d));
            return v;
        }


        public static boolean maxTwo( int a, int b) {
            int sum = a + b;
            if (sum > 10 && sum < 20) return true;
            else return false;
        }

        public static void maxFour( int a) {
            a = 10;
            if (a >= 0) System.out.println("Число " + a + " положительное");
            else System.out.println("Число " + a + " отрицательное");
        }

        public static void maxSix(String name) {
            System.out.println("Привет, " + name + "!");
        }

        public static boolean maxSeven(int year) {
        return year % 100 != 0 && year % 4 == 0 || year % 400 ==0;
    }


}